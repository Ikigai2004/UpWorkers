const chooseColor = document.querySelectorAll(".choose-color__btn");
const contentItem = document.querySelectorAll(".content-item");

// перебираем циклом все елементы и даем им прослушку при нажатии
chooseColor.forEach(e=> e.addEventListener('click',open));
    

function open(evt){
    // Позволяет нам найти элемент по которому нажали
    // ВАЖНО без таргета мы не можем задавать класс элементу
    const target = evt.currentTarget

    // Записываем информацию о датасете в переменную
    const button = target.dataset.button

    // Делаем содержимое датасета классом
    const contentActive = document.querySelectorAll(`.${button}`)

    // добавляем класс, чтобы элемент исчезнул 
    chooseColor.forEach((e)=>e.classList.remove('choose-color__btn--active'))

    // Добавляем класс только нажатому элементу
    target.classList.add('choose-color__btn--active')

    // Убираем все классы 
    contentItem.forEach(item =>item.classList.remove('content-item--active'));
    
    // Пробегаемся по всем классам с нужным цветом и добавляем туда другой класс для отображения картинок
    contentActive.forEach(item=> item.classList.add('content-item--active'));      
    
}

